/*************************************************************************
This library works with Olimexino-328; Olimexino-32U4 and Olimexino-Nano
*************************************************************************/

#include <Arduino.h>
#include <Wire.h>
#include "LCD1x9.h"

#define LCD1x9_SLAVE_ADDR 0x38

LCD1X9::LCD1X9 (void)
{
};

/******************************************************************************
* Description: Initialize(..) - initializes pins and registers of the LCD1x9
*				Also lights up all segments
* Input: 	none
* Output: 	none
* Return:	0 if sucessfully initialized, -1 if error occured 
*******************************************************************************/
void LCD1X9::Initialize()
{
	char i;
	
	#if defined	ARDUINO_AVR_OLIMEXINO_32U4 || ARDUINO_AVR_OLIMEXINO_Nano
	// UEXT power on for Olimexino-32U4 and Olimexino-Nano
	pinMode (8, OUTPUT);
	digitalWrite (8, LOW);
	#endif
	
	Wire.begin ();
	Wire.beginTransmission (LCD1x9_SLAVE_ADDR);
    Wire.write(0xC8);	// mode register
    Wire.write(0xF0);	// blink register
    Wire.write(0xE0);	// device select register
    Wire.write(0x00);	// pointer register

	// light up all the segments, initialize the local display buffer as well
	for(i = 0; i < 20; i++)
	{
		Wire.write(0xFF);
		lcdBitmap[i] = 0xFF;
	}

    Wire.endTransmission();
}


/******************************************************************************
* Description: enableSegment(..) - enables a segment in the display buffer
*		Note: Does not actually light up the segment, have to call the 'Update(..)'
* Input: 	comIndex - backplate index
*			bitIndex - segment index
* Output: 	none
* Return:	none
*******************************************************************************/
void LCD1X9::enableSegment(BYTE comIndex, BYTE bitIndex)
{
	if(bitIndex >= 40)
		return;

	comIndex &= 0x3;

	if(bitIndex & 0x1)
		comIndex |= 0x4;
		
	bitIndex >>= 1;

	lcdBitmap[bitIndex] |= 0x80 >> comIndex;
}

/******************************************************************************
* Description: disableSegment(..) - disables a segment in the display buffer
*		Note: Does not actually lights off the segment, have to call the 'Update(..)'
* Input: 	comIndex - backplate index
*			bitIndex - segment index
* Output: 	none
* Return:	none
*******************************************************************************/
void LCD1X9::disableSegment(BYTE comIndex, BYTE bitIndex)
{
	if(bitIndex >= 40)
		return;

	comIndex &= 0x3;

	if(bitIndex & 0x1)
		comIndex |= 0x4;

	bitIndex >>= 1;

	lcdBitmap[bitIndex] &= ~(0x80 >> comIndex);
}

/******************************************************************************
* Description: Update(..) - disables a segment in the display buffer
*		Note: Does not actually lights off the segment, have to call the 'Update(..)'
* Input: 	comIndex - backplate index
*			bitIndex - segment index
* Output: 	none
* Return:	none
*******************************************************************************/
void LCD1X9::Update(void)
{
	BYTE i;

    Wire.begin();
	Wire.beginTransmission (LCD1x9_SLAVE_ADDR);
	Wire.write (0xE0);
	Wire.write (0x00);
	// send the local buffer to the device
	for(i = 0; i < 20; i++)
		Wire.write (lcdBitmap[i]);
	Wire.endTransmission ();
}

/******************************************************************************
* Description: Write(..) - writes a string to the display
* Input: 	string - the string to write, no more than 9 characters
*			bitIndex - segment index
* Output: 	none
* Return:	none
*******************************************************************************/
void LCD1X9::Write(char *string)
{
	BYTE data, length, index, i;
	WORD bitfield;
	BYTE com, bit;

	length = strlen(string);
	if(length > 9)
		return;

	index  = 0;
	/* fill out all characters on display */
	for (index = 0; index < 9; index++)
	{
		if (index < length)
		{
			data = (BYTE)string[index];
		}
		else
		{
			data = 0x20; // fill with spaces if string is shorter than display
		}

		data -= 0x20;
		bitfield = LCDAlphabet[data];

		for (i = 0; i < 16; i++)
		{
			bit = LCD1x9.Text[index].bit[i];
			com = LCD1x9.Text[index].com[i];
		
			if (bitfield & ((WORD)1 << i))
			{
				enableSegment(com, bit);
			}
			else
			{
				disableSegment(com, bit);
			}
		}
	}

	Update();
}

/******************************************************************************
* Description: WriteROM(..) - writes a string to the display
* Input: 	string - the string to write, no more than 9 characters
*			bitIndex - segment index
* Output: 	none
* Return:	none
*******************************************************************************/
void LCD1X9::WriteROM(const char* string)
{
	BYTE data, length, index, i;
	WORD bitfield;
	BYTE com, bit;

	length = (BYTE)strlen(string);

	index  = 0;
	/* fill out all characters on display */
	for (index = 0; index < 9; index++)
	{
		if (index < length)
		{
			data = (BYTE)string[index];
		}
		else
		{
			data = 0x20; // fill with spaces if string is shorter than display
		}

		data -= 0x20;
		bitfield = LCDAlphabet[data];

		for (i = 0; i < 16; i++)
		{
			bit = LCD1x9.Text[index].bit[i];
			com = LCD1x9.Text[index].com[i];
		
			if (bitfield & ((WORD)1 << i))
			{
				enableSegment(com, bit);
			}
			else
			{
				disableSegment(com, bit);
			}
		}
	}

	Update();
}
