Demo library and examples compatible with Olimex BB-ADS1262.

The library and the example are written by VenkateshBhat the latest version of the original library could be found here: https://github.com/Protocentral/ProtoCentral_ads1262. The example has been adapted so it works with Olimex boards Olimexino-328 and OLIMEXINO-32U4. In order to work you need to connect the pins as it is described in the header comment on the demo sketch.
If you use any of this code in your project, please respect the original creator of this library and example.

Tested with Olimex OLIMEXINO-328 and OLIMEXINO-32U4 board and Arduino IDE v1.8.5.

Olimex, 13.04.2018
