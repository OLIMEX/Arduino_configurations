#ifndef Arduino_h
#define Arduino_h

#include <WProgram.h>

#endif
