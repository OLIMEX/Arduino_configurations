OLIMEXINO-85-ASM, OLIMEXINO-85-KIT and FOSDEM-85 example package

1. Hardware and software prerequisites:

1x OLIMEXINO-85 board
1x cable to connect the board and your PC
1x properly installed Arduino 1.6.9 (with installed Olimex package)

Some examples require additional hardware! Each example has explanation in the code comments!

Note: Since the I2C buffer inside the TinyWireM library (which is install together with the Arduino IDE) is too short (18) for some of the examples that use I2C you may have to increase it to 30. The macro for the buffer size is in "..\Documents\Arduino\libraries\TinyWireM\TinyWireM.h" line 44.
#define USI_BUF_SIZE    18              // bytes in message buffer
must be changed to:
#define USI_BUF_SIZE    30              // bytes in message buffer

If you are using the library for other applications you may revert it to its default value --> 18.

2. The example list consists of:
O85_ADCtoPWM
O85_BB_A4983
O85_BB_VNH3SP30
O85_BlinkingLed
O85_Button
O85_MOD_IRDA_LED_STRIPE_16
O85_MOD_LCD_1x9
O85_MOD_LTR501ALS_LED_STRIPE_16
O85_MOD_TC_MK2
O85_MOD_WII_UEXT_NUNCHUCK_LED_STRIPE
O85_PIEZZO_KNOCK_LED_STRIPE_16
O85_PONG_GAME
O85_PWM
O85_Thermometer

3. Remember:
- to upload the program you must first select "Tools → board" as "Olimexino-85"
- you need to click "Upload" button first, wait for the program to compile and THEN plug the board - this is because the bootloader implementation runs for the first few seconds after power up and then the user program is executed. If you plug the board before programming the bootloader won't be available and uploading will fail. Disconnect the board, click "Upload" again and then connect the board. 
