This file describes how to upload into the EEPROM memory of RGB-Glasses and the different options that the demo supports.


The input file must contain different lines one of the following commands:

"-c" or "-C" - set the color of the text (the color could be changed eventually from the accelerometer data)
example: -c 0x200000

"-b" or "-B" - set the background color
example: -B 0x000A00

"-s" or "-S" - set the delay in milliseconds between each slide of the text
example: -s 100

"-t" or "-T" - set the text to be displayed
example: -T This is a test message!

"-p" or "-P" - stop the program for the selected time
example: -p 1500


The symbol '/' in the beginning of line causes the interpreter to ignore the selected line, but the text will be stored in the EEPROM memory, and '@' will indicate end of the data after which the program will start from address 0 of the EEPROM.

Content of Demo_Slide_Sample_Input.txt file:
----------------------------------------------------------
-c 0x002000
-S 150
-t This is the first message!
-P 1000
-c 0x200000
/-b 0x000200
-t Hello world!
-P 2000
-s 200
-C 0x202000
-t Deal with it!
-B 0x030000
-p 0x1000
/-t This message is commented!
-C 0x000020
-p 1500
-t The background is red!
-P 1000
-s 100
-c 0x300000
-b 0x000002
-t Just another long test message with short delay.
-p 1000
@
-t This message WILL NOT be displayed!
----------------------------------------------------------

Note: In this example above since no background color is set before first displaying of text, the default background color is 0x000000, but when it starts again after '@' is reached the background color is set as -b 0x000002 (the last one). It is the same with color and sliding speed values - if you don't want to have differences between first and second display make sure you initialize all the parameters.


In order to upload the data from the file into the EEPROM memory:
1) Run Command prompt (Start --> "cmd")

2) Select the folder of Olimex version of micronucleus.exe. For EXAMPLE (path will differs) the path should be something like:
cd "C:\Users\Test-Windows7-x64\AppData\Roaming\Arduino15\packages\Olimex\tools\micronucleus\1.0.0"

3) Unplug the device

4) Run micronucleus with option to write in EEPROM memory "--write-eeprom" followed by the path and name of the file. For EXAMPLE:
micronucleus.exe --write-eeprom "C:\Users\Test-Windows7-x64\AppData\Roaming\Arduino15\packages\Olimex\hardware\avr\1.2.1\libraries\examples\RGB-Glasses\Slide_Text_Accelerometer\Demo_Slide_Sample_Input.txt"

5) Plug the device and wait until upload is complete

If everything is fine the content of the file is stored inside the EEPROM memory and when you upload the demo the text will start to slide on the LEDs.