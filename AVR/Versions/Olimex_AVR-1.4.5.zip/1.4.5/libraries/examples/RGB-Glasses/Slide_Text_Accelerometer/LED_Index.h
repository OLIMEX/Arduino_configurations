#ifndef	_LED_INDEX_H
#define	_LED_INDEX_H

#include <avr/pgmspace.h>

extern const char LED_Matrix_Index[5][14] PROGMEM;

#endif
