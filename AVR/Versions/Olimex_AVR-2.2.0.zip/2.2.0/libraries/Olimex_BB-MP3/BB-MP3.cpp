#include "BB-MP3.h"

BB_MP3::BB_MP3()
{
}

BB_MP3::~BB_MP3()
{
}

// utility functions
void BB_MP3::SendCmd(int len)
{
	unsigned char i = 0 ;

	SERIAL.write(0x7E);    // Sending the Start bit
	for(i=0; i<len; i++)
		SERIAL.write(Send_buf[i]) ;
	SERIAL.write(0xEF) ;  // Sending the Stop bit
}

void BB_MP3::DoSum(unsigned char *Str, unsigned char len)
{
	int xorsum = 0;
	unsigned char i;

	for(i=0; i<len; i++)
	xorsum = xorsum + Str[i];
	xorsum = 0 -xorsum;
	*(Str+i) = (unsigned char)(xorsum >>8);
	*(Str+i+1) = (unsigned char)(xorsum & 0x00ff);
}

void BB_MP3::Uart_SendCMD(unsigned char CMD ,unsigned char feedback , int dat)
{
	Send_buf[0] = 0xff;      // Version Information
	Send_buf[1] = 0x06;      // Data Length
	Send_buf[2] = CMD;       // Command
	Send_buf[3] = feedback;  // Feedback
	Send_buf[4] = (unsigned char)(dat >> 8);  //datah
	Send_buf[5] = (unsigned char)(dat);       //datal
	DoSum(&Send_buf[0],6);    // CRC Checksum
	SendCmd(8);
	delay(Delay_time_ms);     // Wait 20ms before the next instruction
}


// user functions
void BB_MP3:: NextSong ()
{
	Uart_SendCMD(0x01,0,0x0001);
}

void BB_MP3:: PreviousSong ()
{
	Uart_SendCMD(0x02,0,0x0001);
}

void BB_MP3:: Song (int Index)
{
	Uart_SendCMD(0x03,0,Index);	// TODO?
}

void BB_MP3:: VolumeUp ()
{
	Uart_SendCMD(0x04,0,0x0001);
}

void BB_MP3:: VolumeDown ()
{
	Uart_SendCMD(0x05,0,0x0001);
}

void BB_MP3:: Volume (int Value)
{
	if (Value < 0)
		Value = 0;
	if (Value > 30)
		Value = 30;
	Uart_SendCMD(0x06,0,Value);
}

void BB_MP3:: CycleSong (int Index)
{
	Uart_SendCMD(0x08,0,Index);
}

void BB_MP3:: SelectDevice (int Index)
{
	Uart_SendCMD(0x09,0,Index);
}

void BB_MP3:: Sleep ()
{
	Uart_SendCMD(0x0A,0,0x0000);
}

void BB_MP3:: WakeUp ()
{
	Uart_SendCMD(0x0B,0,0x0000);
}

void BB_MP3:: Reset ()
{
	Uart_SendCMD(0x0C,0,0x0000);
}

void BB_MP3:: Play ()
{
	Uart_SendCMD(0x0D,0,0x0000);
}

void BB_MP3:: Pause ()
{
	Uart_SendCMD(0x0E,0,0x0000);
}

void BB_MP3:: FolderSong (int Dir, int Song)
{
	unsigned int Value;
	Value = (Dir<<8) | Song;
	Uart_SendCMD(0x0F,0,Value);
}

void BB_MP3:: Stop ()
{
	Uart_SendCMD(0x16,0,0x0000);
}

void BB_MP3:: CycleFolder (int Dir)
{
	Uart_SendCMD(0x17,0,Dir);
}

void BB_MP3:: Shuffle ()
{
	Uart_SendCMD(0x18,0,0x0000);
}

void BB_MP3:: Repeat (int Mode)
{
	Uart_SendCMD(0x0A,0,Mode);
}
