/*************************************************************************
This library works with Olimexino-328; Olimexino-32U4 and Olimexino-Nano
*************************************************************************/

#ifndef _LCD1x9_DRIVER_H
#define _LCD1x9_DRIVER_H

#include "LCD1x9_mapping.h"

typedef	unsigned char BYTE;
typedef	unsigned int WORD;
class LCD1X9
{
	BYTE lcdBitmap[20]; // 40segments * 4 = 160px, 160 / 8 = 20bytes
	public:
	LCD1X9(void);
	void Initialize();
	void enableSegment(BYTE comIndex, BYTE bitIndex);
	void disableSegment(BYTE comIndex, BYTE bitIndex);
	void Update(void);
	void Write(char *string);
	void WriteROM(const char* string); // same thing but with ROM string
};

#endif // _LCD1x9_DRIVER_H
