#ifndef	_FONT_H
#define	_FONT_H

#include <avr/pgmspace.h>


// define the macro which corresponds to your font size
//#define  FONT_7X5
#define  FONT_5X5

extern const unsigned char  FontLookup [][5] PROGMEM;

#endif
