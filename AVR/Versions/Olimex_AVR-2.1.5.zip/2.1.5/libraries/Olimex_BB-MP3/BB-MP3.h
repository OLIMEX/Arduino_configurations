#ifndef	_BB_MP3_H
#define	_BB_MP3_H

#include "Arduino.h"

#if		defined	(ARDUINO_AVR_OLIMEXINO_32U4)
#define	SERIAL	Serial1
#elif	defined	(ARDUINO_AVR_OLIMEXINO_328)
#define	SERIAL	Serial
#else
#define	SERIAL	Serial
#endif

#define  Delay_time_ms    20

class BB_MP3
{
	unsigned char Send_buf[10];
	// utility functions (private)
	void SendCmd (int Len);
	void DoSum(unsigned char *Str, unsigned char len);
	void Uart_SendCMD(unsigned char CMD ,unsigned char feedback , int dat);

	public:
	BB_MP3 ();
	~BB_MP3 ();

	void NextSong ();
	void PreviousSong ();
	void Song (int Index);
	void VolumeUp ();
	void VolumeDown ();
	void Volume (int Value);
	void CycleSong (int Index);
	void SelectDevice (int Index);
	void Sleep ();
	void WakeUp ();
	void Reset ();
	void Play ();
	void Pause ();
	void FolderSong (int Dir, int Song);
	void Stop ();
	void CycleFolder (int Dir);
	void Shuffle ();
	void Repeat (int Mode);
	
	/*
	// TODO
	void DAC (int Mode);
	PlayGroup ();
	PlayVolume ();
	*/
};

#endif