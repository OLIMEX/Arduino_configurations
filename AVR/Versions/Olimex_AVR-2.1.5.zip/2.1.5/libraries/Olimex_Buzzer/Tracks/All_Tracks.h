#ifndef	_ALL_TRACKS_H
#define	_ALL_TRACKS_H

#include "../Notes.h"
#include "Imperial_March.h"
#include "Amazing_Grace.h"
#include "Mario_Bros.h"
#include "Mario_Bros_Underwater.h"
#include "Silent_Night_Holy_Night.h"

#endif
