FONT_5X5.txt - visualisation of the font with # character (horizontal described)
FONT_5X5_Commented - has an array with comment on each line about the character
Numbers - the array described ONLY with numbers (no brackets or comments). This is the input file to the Converter.exe
Converter.cpp / .exe - Source and executable file of the converter from horizontal orientation to vertical. Requires name of the input file (Numbers.txt) and output file (for example Out.txt)

After that you can copy --> paste the content of the generated file into your font array. Keep in my about the '\' (line 61) character since it is an special symbol and it makes the next line to be considered the same as the previous one making the next character be commented. So you have to replace/remove it.