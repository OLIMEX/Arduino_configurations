Demo for PIC32-Pinguino-OTG rev.D and MOD-LCD3310 Rev.A attached to the UEXT.

Project is built and tested with Pinguino IDE rev 959.

This folder must be copied inside: "..\Pinguino\x4-easy-rev959\p32\include\pinguino\libraries\" (the path must not contain spaces). And then open the provided example.

On the LCD should be displayed a simple text message on 6 lines. 3 of them should be with black background and white letters and the other three black letters on white background. When you press the button the colors will be inverted.