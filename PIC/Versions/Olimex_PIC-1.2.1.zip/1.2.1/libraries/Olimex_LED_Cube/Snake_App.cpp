#include "Snake_App.h"
#include "Arduino.h"

Snake::Snake ()
{
	// randomize the pseudo-random generator by giving a value from the analog input
	randomSeed(analogRead(A0));
	// initialize snake and food
	Length = 0;
	Head = {0, 0, 0};
	Direction = {0, 0, 1};
	Food = {random (0, 8), random (0, 8), random (0, 8)};
}

void Snake::Reset (void)
{	// randomize the pseudo-random generator by giving a value from the analog input
	randomSeed(analogRead(A0));
	// initialize snake and food
	Length = 0;
	Head = {0, 0, 0};
	Direction = {0, 0, 1};
	Food = {random (0, 8), random (0, 8), random (0, 8)};
}

int Snake::Update (void)
{
	int i;
	bool Food_in_Body = false;
	// eat food check
	if ((Head.X+Direction.X==Food.X) && (Head.Y+Direction.Y==Food.Y) && (Head.Z+Direction.Z==Food.Z))
	{
		// increase the size of the snake
		Length++;

		// next food must not spawn inside the head/body
		do
		{
			Food_in_Body = false;
			Food = {random (0, 8), random (0, 8), random (0, 8)};
			if ((Head.X == Food.X) && (Head.Y == Food.Y) && (Head.Z == Food.Z))
				continue;
			for (i=0; i<Length; i++)
				if ((Body[i].X == Food.X) && (Body[i].Y == Food.Y) && (Body[i].Z == Food.Z))
				{
					Food_in_Body = true;
					break;
				}
		}
		while (Food_in_Body);
	}

	// move the body with one position
	for (i=Length-1; i>0; i--)
		Body[i] = Body[i-1];
	Body[0] = Head;

	// Move the head to the next field
	Head.X = Head.X+Direction.X;
	Head.Y = Head.Y+Direction.Y;
	Head.Z = Head.Z+Direction.Z;

	// check for death after update
	return Dead_Check ();
}

int Snake::Dead_Check ()
{
	int i;
	// hit the wall checks
	if (Head.X<0 || Head.X>7)
		return -1;
	if (Head.Y<0 || Head.Y>7)
		return -1;
	if (Head.Z<0 || Head.Z>7)
		return -1;

	// selfbite check
	for (i=0; i<Length; i++)
		if ((Head.X == Body[i].X) && (Head.Y == Body[i].Y) && (Head.Z == Body[i].Z))
			return -2;

	return 0;
}

// this method (as the name suggests) is used only for debug purposes
// it prints the value of the snake member variables and stops the program until an input of a new line
void Snake::Debug (void)
{
	char Buffer[32];
	Serial.println ("------");
	sprintf (Buffer, "Head: %d %d %d\n", Head.X, Head.Y, Head.Z); Serial.print (Buffer);
	for(int i=0; i<Length; i++)
	{
		sprintf (Buffer, "Body[%d]: %d %d %d\n", i, Body[i].X, Body[i].Y, Body[i].Z); Serial.print (Buffer);
	}
	sprintf (Buffer, "Food: %d %d %d\n", Food.X, Food.Y, Food.Z); Serial.print (Buffer);
	sprintf (Buffer, "Direction: %d %d %d\n", Direction.X, Direction.Y, Direction.Z); Serial.print (Buffer);
	while (Serial.read()!=10);\
	Serial.println ("------");
	return;
}
