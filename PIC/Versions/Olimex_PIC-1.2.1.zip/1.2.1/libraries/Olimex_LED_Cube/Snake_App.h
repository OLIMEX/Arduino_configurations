#ifndef	_SNAKE_APP
#define	_SNAKE_APP

#define	MAX_SIZE	100

struct XYZ
{
  char X, Y, Z;
};

class Snake
{
public:
  XYZ Head, Body[MAX_SIZE], Direction, Food;
  int Length;

  Snake ();
  void Reset (void);
  int Update ();
  int Dead_Check ();
  
  void Debug ();
};

#endif
