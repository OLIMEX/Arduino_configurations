SD card demo

This is a sample demo project for PIC32-Pinguino board
for SD card based on the SD library example - CardInfo.
Since the board itself has no SD card slot for this demo
MOD-SDMMC is connected to the UEXT module and it communicates
with the master via SPI.

For PIC32-Pinguino hardware SPI pins are:
MOSI   - D11
MISO   - D12
SCK    - D13
SS     - D10 (this is the slave select of the hardware SPI)
CS     - D36 (this is the chip select on board UEXT, RF0)

After initializing the hardware in the main loop periodically 
the program will scan for card, initialize it and show some info:
card type, files system, volume size and files and folders that contains.

Build and hardware info:
PIC32-Pinguino rev.C
MOD-SDMMC rev.A
Arduino IDE v1.6.11

Stanimir Petev, Olimex LTD
2016.09.16
