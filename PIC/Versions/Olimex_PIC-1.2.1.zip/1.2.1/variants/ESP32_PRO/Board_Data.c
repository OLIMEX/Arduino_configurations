/************************************************************************/
/*																		*/
/*	Board_Data.c --	Default Board Customization Data Declarations		*/
/*																		*/
/************************************************************************/
/*	Author: Gene Apperson												*/
/*	Copyright 2011, Digilent. All rights reserved						*/
/************************************************************************/
/*  File Description:													*/
/*																		*/
/* This file contains the board specific declarations and data structure*/
/* to customize the chipKIT MPIDE for use with a generic board using a	*/
/* PIC32 part in a 64-pin package.										*/
/*																		*/
/* This code is based on earlier work:									*/
/*		Copyright (c) 2010, 2011 by Mark Sproul							*/
/*		Copyright (c) 2005, 2006 by David A. Mellis						*/
/*																		*/
/************************************************************************/
/*  Revision History:													*/
/*																		*/
/*	11/28/2011(GeneA): Created by splitting data out of Board_Defs.h	*/
/*  03/11/2012(BrianS): Modified for Fubarino board                     */
/*	02/12/2013(GeneA): removed dependency on Microchip plib library		*/
/*																		*/
/************************************************************************/
//*	This library is free software; you can redistribute it and/or
//*	modify it under the terms of the GNU Lesser General Public
//*	License as published by the Free Software Foundation; either
//*	version 2.1 of the License, or (at your option) any later version.
//*	
//*	This library is distributed in the hope that it will be useful,
//*	but WITHOUT ANY WARRANTY; without even the implied warranty of
//*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//*	Lesser General Public License for more details.
//*	
//*	You should have received a copy of the GNU Lesser General
//*	Public License along with this library; if not, write to the
//*	Free Software Foundation, Inc., 59 Temple Place, Suite 330,
//*	Boston, MA  02111-1307  USA
/************************************************************************/

#if !defined(BOARD_DATA_C)
#define BOARD_DATA_C

#include <inttypes.h>

/* ------------------------------------------------------------ */
/*					Data Tables									*/
/* ------------------------------------------------------------ */
/* The following declarations define data used in pin mapping.	*/
/* ------------------------------------------------------------ */

#if defined(OPT_BOARD_DATA)

/* ------------------------------------------------------------ */
/* This table is used to map from port number to the address of
** the TRIS register for the port. This is used for setting the
** pin direction.
*/
const uint32_t	port_to_tris_PGM[] =
{
	NOT_A_PORT,				//index value 0 is not used

#if defined(_PORTA)
	(uint32_t)&TRISA,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTB)
	(uint32_t)&TRISB,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTC)
	(uint32_t)&TRISC,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTD)
	(uint32_t)&TRISD,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTE)
	(uint32_t)&TRISE,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTF)
	(uint32_t)&TRISF,
#else
	NOT_A_PORT,
#endif

#if defined(_PORTG)
	(uint32_t)&TRISG,
#else
	NOT_A_PORT,
#endif

	NOT_A_PORT,
};

/* ------------------------------------------------------------ */
/* This table is used to map the digital pin number to the port
** containing that pin. The default mapping is to assign pin numbers
** for every possible port bit in order from PORTA to PORTG.
*/
const uint8_t	digital_pin_to_port_PGM[] =
{
	// 13 arduino digital GPIO
	_IOPORT_PC,	//  00  RC8		U2RX
	_IOPORT_PC,	//  01  RC9		U2TX
	_IOPORT_PC,	//  02  RC2
	_IOPORT_PC,	//  03  RC3
	_IOPORT_PC,	//  04  RC4
	_IOPORT_PC,	//  05  RC5
	_IOPORT_PC,	//  06  RC6
	_IOPORT_PC,	//  07  RC7

	_IOPORT_PB,	//  08  RB7		BUT
	_IOPORT_PA,	//  09  RA10	LED2
	_IOPORT_PB,	//  10  RB5		SD02
	_IOPORT_PB,	//  11  RB13	SDI2
	_IOPORT_PB,	//  12  RB15	SCK2/LED1

	// 8 special purpose digital ports
	_IOPORT_PA,	//  13 RA7	SS	(UEXT SPI)
	_IOPORT_PA,	//  14 RA9	SDO1(UEXT SPI)
	_IOPORT_PA,	//  15 RA8	SDI1(UEXT SPI)
	_IOPORT_PB,	//  16 RB14 SCK1(UEXT SPI)
	_IOPORT_PB,	//  17 RB8  SCL1(UEXT I2C)
	_IOPORT_PB,	//  18 RB9  SDA1(UEXT I2C)
	_IOPORT_PA,	//  19 RA4  U1RX
	_IOPORT_PB,	//  20 RB4  U1TX

	// 6 analog ports
    _IOPORT_PB,	//  21 RB0  A0  AN2
	_IOPORT_PB,	//  22 RB1  A1  AN3
	_IOPORT_PB,	//  23 RB2  A2  AN4
	_IOPORT_PB,	//  24 RB3  A3  AN5
	_IOPORT_PB,	//  25 RB13 A4  AN11
	_IOPORT_PC,	//  26 RC0  A5  AN6/(SCL2)
	_IOPORT_PA,	//  27 RA0  A6  AN0
	_IOPORT_PA,	//  28 RA1  A7  AN1
};

/* ------------------------------------------------------------ */
/* This table is used to map from digital pin number to a bit mask
** for the corresponding bit within the port.
*/
const uint16_t	digital_pin_to_bit_mask_PGM[] =
{
	// 13 arduino digital GPIO
	_BV( 8 ) ,	//  00  RC8		U2RX
	_BV( 9 ) ,	//  01  RC9		U2TX
	_BV( 2 ) ,	//  02  RC2
	_BV( 3 ) ,	//  03  RC3
	_BV( 4 ) ,	//  04  RC4
	_BV( 5 ) ,	//  05  RC5
	_BV( 6 ) ,	//  06  RC6
	_BV( 7 ) ,	//  07  RC7

	_BV( 7 ) ,	//  08  RB7		BUT
	_BV( 10) ,	//  09  RA10	LED2
	_BV( 5 ) ,	//  10  RB5		SS
	_BV( 13) ,	//  11  RB13	SDI2
	_BV( 15) ,	//  12  RB15	SCK2/LED1
	
	// 8 special purpose digital ports
	_BV( 7 ) ,	//  13 RA7	SS	(UEXT SPI)
	_BV( 9 ) ,	//  14 RA9	SDO1(UEXT SPI)
	_BV( 8 ) ,	//  15 RA8	SDI1(UEXT SPI)
	_BV( 14) ,	//  16 RB14 SCK1(UEXT SPI)
	_BV( 8 ) ,	//  17 RB8  SCL1(UEXT I2C)
	_BV( 9 ) ,	//  18 RB9  SDA1(UEXT I2C)
	_BV( 4 ) ,	//  19 RA4  U1RX
	_BV( 4 ) ,	//  20 RB4  U1TX

	// 6 analog ports
    _BV( 0 ) ,	//  21 RB0  A0  AN2
	_BV( 1 ) ,	//  22 RB1  A1  AN3
	_BV( 2 ) ,	//  23 RB2  A2  AN4
	_BV( 3 ) ,	//  24 RB3  A3  AN5
	_BV( 13 ) ,	//  25 RB13  A4  AN11
	_BV( 0 ) ,	//  26 RC0  A5  AN6
	_BV( 0 ) ,      //  27 RA0  A6  AN0
	_BV( 1 ) ,      //  28 RA1  A7  AN1
};
/* ------------------------------------------------------------ */
/* This table is used to map from digital pin number to the output
** compare number, input capture number, and timer external clock
** input associated with that pin.
*/
const uint16_t	digital_pin_to_timer_PGM[] =
{
	// 13 arduino digital GPIO
	NOT_ON_TIMER,	//  00  RC8		U2RX
	NOT_ON_TIMER,	//  01  RC9		U2TX
	NOT_ON_TIMER,	//  02  RC2
	NOT_ON_TIMER,	//  03  RC3
	NOT_ON_TIMER,	//  04  RC4
	NOT_ON_TIMER,	//  05  RC5
	NOT_ON_TIMER,	//  06  RC6
	NOT_ON_TIMER,	//  07  RC7

	NOT_ON_TIMER,	//  08  RB7		BUT
	NOT_ON_TIMER,	//	_PPS_OUT(_PPS_RPA10),//  09  RA10	LED2
	NOT_ON_TIMER,	//  10  RB5		SD02
	NOT_ON_TIMER,	//  11  RB13	SDI2
	NOT_ON_TIMER,	//  12  RB15	SCK2/LED1

	// 8 special purpose digital ports
	NOT_ON_TIMER,	//  13	_PPS_OUT(_PPS_RPA7),	//  14 RA7	SS	(UEXT SPI)
	NOT_ON_TIMER,	//  14 RA9	SDO1(UEXT SPI)
	NOT_ON_TIMER,	//  15 RA8	SDI1(UEXT SPI)
	NOT_ON_TIMER,	//  16 RB14 SCK1(UEXT SPI)
	NOT_ON_TIMER,	//  17 RB8  SCL1(UEXT I2C)
	NOT_ON_TIMER,	//  18 RB9  SDA1(UEXT I2C)
	_TIMER_OC1,	//  19 RA4  U1RX
	NOT_ON_TIMER,	//  20 RB4  U1TX

	// 6 analog ports
     NOT_ON_TIMER,	//  21 RB0  A0  AN2
	NOT_ON_TIMER,	//  22 RB1  A1  AN3
	NOT_ON_TIMER,	//  23 RB2  A2  AN4
	NOT_ON_TIMER,	//  24 RB3  A3  AN5
	NOT_ON_TIMER,	//  25 RB13  A4  AN11
	NOT_ON_TIMER,	//  26 RC0  A5  AN6
	NOT_ON_TIMER,	//  27 RA0  A6  AN0
	NOT_ON_TIMER,	//  28 RA1  A7  AN1
};

/* ------------------------------------------------------------ */
/* This table maps from a digital pin number to the corresponding
** PPS register. This register is used to select the peripheral output
** connected to the pin. The register is set to 0 to disconnect the
** pin from any peripheral so it can be used as GPIO.
** For PIC32MX1xx/2xx series devices, the PPS output select registers
** are arranged as a contiguous series of 32 bit registers. This table
** treats these registers as an array of DWORDs an stores the index
** to the register.
*/
const uint8_t digital_pin_to_pps_out_PGM[] =
{
	// 13 arduino digital GPIO
	_PPS_OUT(_PPS_RPC8R),	//  00  RC8		U2RX
	_PPS_OUT(_PPS_RPC9R),	//  01  RC9		U2TX
	_PPS_OUT(_PPS_RPC2R),	//  02  RC2
	_PPS_OUT(_PPS_RPC3R),	//  03  RC3
	_PPS_OUT(_PPS_RPC4R),	//  04  RC4
	_PPS_OUT(_PPS_RPC5R),	//  05  RC5
	_PPS_OUT(_PPS_RPC6R),	//  06  RC6
	_PPS_OUT(_PPS_RPC7R),	//  07  RC7

	_PPS_OUT(_PPS_RPB7R),	//  08  RB7		BUT
	NOT_PPS_PIN,			//	_PPS_OUT(_PPS_RPA10),//  09  RA10	LED2
	_PPS_OUT(_PPS_RPB5R),	//  10  RB5		SD02
	_PPS_OUT(_PPS_RPB13R),	//  11  RB13	SDI2
	_PPS_OUT(_PPS_RPB15R),	//  12  RB15	SCK2/LED1

	// 8 special purpose digital ports
	NOT_PPS_PIN,			//	_PPS_OUT(_PPS_RPA7),	//  13 RA7	SS	(UEXT SPI)
	_PPS_OUT(_PPS_RPA9R),	//  14 RA9	SDO1(UEXT SPI)
	_PPS_OUT(_PPS_RPA8R),	//  15 RA8	SDI1(UEXT SPI)
	_PPS_OUT(_PPS_RPB14R),	//  16 RB14 SCK1(UEXT SPI)
	_PPS_OUT(_PPS_RPB8R),	//  17 RB8  SCL1(UEXT I2C)
	_PPS_OUT(_PPS_RPB9R),	//  18 RB9  SDA1(UEXT I2C)
	_PPS_OUT(_PPS_RPA4R),	//  19 RA4  U1RX
	_PPS_OUT(_PPS_RPB4R),	//  20 RB4  U1TX

	// 6 analog ports
    _PPS_OUT(_PPS_RPB0R),	//  21 RB0  A0  AN2
	_PPS_OUT(_PPS_RPB1R),	//  22 RB1  A1  AN3
	_PPS_OUT(_PPS_RPB2R),	//  23 RB2  A2  AN4
	_PPS_OUT(_PPS_RPB3R),	//  24 RB3  A3  AN5
	_PPS_OUT(_PPS_RPB13R),	//  25 RB13  A4  AN11
	_PPS_OUT(_PPS_RPC0R),	//  26 RC0  A5  AN6
	_PPS_OUT(_PPS_RPA0R),	//  27 RA0  A6  AN0
	_PPS_OUT(_PPS_RPA1R),	//  28 RA1  A7  AN1	
};

/* ------------------------------------------------------------ */
/* This table maps from the digital pin number to the value to be
** loaded into a PPS input select register to select that pin.
** It also maps from digital pin number to input/output pin set to 
** which the pin belongs. The set mask is in the high four bits,
** the select value is in the low four bits.
** Note: if the PIC32 device has more than four pin sets, or more than
** 16 pin mapping choices per input function, then this table will have
** to be redefined as a table of uint16_t values and the macros used to
** access the table redefined as well.
*/
const uint8_t digital_pin_to_pps_in_PGM[] =
{
	// 13 arduino digital GPIO
	_PPS_IN(_PPS_RPC8),	//  00  RC8		U2RX
	_PPS_IN(_PPS_RPC9),	//  01  RC9		U2TX
	_PPS_IN(_PPS_RPC2),	//  02  RC2
	_PPS_IN(_PPS_RPC3),	//  03  RC3
	_PPS_IN(_PPS_RPC4),	//  04  RC4
	_PPS_IN(_PPS_RPC5),	//  05  RC5
	_PPS_IN(_PPS_RPC6),	//  06  RC6
	_PPS_IN(_PPS_RPC7),	//  07  RC7

	_PPS_IN(_PPS_RPB7),	//  08  RB7		BUT
	NOT_PPS_PIN,		//	_PPS_IN(_PPS_RPA10),//  09  RA10	LED2
	_PPS_IN(_PPS_RPB5),	//  10  RB5		SD02
	_PPS_IN(_PPS_RPB13), 	//  11  RB13	SDI2
	_PPS_IN(_PPS_RPB15), 	//  12  RB15	SCK2/LED1

	// 8 special purpose digital ports
	NOT_PPS_PIN,		//	_PPS_IN(_PPS_RPA7),	//  14 RA7	SS	(UEXT SPI)
	_PPS_IN(_PPS_RPA9),	//  14 RA9	SDO1(UEXT SPI)
	_PPS_IN(_PPS_RPA8),	//  15 RA8	SDI1(UEXT SPI)
	_PPS_IN(_PPS_RPB14),	//  16 RB14 SCK1(UEXT SPI)
	_PPS_IN(_PPS_RPB8),	//  17 RB8  SCL1(UEXT I2C)
	_PPS_IN(_PPS_RPB9),	//  18 RB9  SDA1(UEXT I2C)
	_PPS_IN(_PPS_RPA4),	//  19 RA4  U1RX
	_PPS_IN(_PPS_RPB4),	//  20 RB4  U1TX

	// 6 analog ports
    _PPS_IN(_PPS_RPB0),	//  21 RB0  A0  AN2
	_PPS_IN(_PPS_RPB1),	//  22 RB1  A1  AN3
	_PPS_IN(_PPS_RPB2),	//  23 RB2  A2  AN4
	_PPS_IN(_PPS_RPB3),	//  24 RB3  A3  AN5
	_PPS_IN(_PPS_RPB13),	//  25 RB13  A4  AN11
	_PPS_IN(_PPS_RPC0),	//  26 RC0  A5  AN6)
	_PPS_IN(_PPS_RPA0),	//  27 RA0  A6  AN0
	_PPS_IN(_PPS_RPA1),	//  28 RA1  A7  AN1
};

/* ------------------------------------------------------------ */
/* This table maps from a digital pin number to the corresponding
** analog pin number.
*/
//#if defined(_NOT_USED_)
const uint8_t digital_pin_to_analog_PGM[] =
{
	// 13 arduino digital GPIO
	NOT_ANALOG_PIN,	//  00  RC8		U2RX
	NOT_ANALOG_PIN,	//  01  RC9		U2TX
	NOT_ANALOG_PIN,	//  02  RC2
	NOT_ANALOG_PIN,	//  03  RC3
	NOT_ANALOG_PIN,	//  04  RC4
	NOT_ANALOG_PIN,	//  05  RC5
	NOT_ANALOG_PIN,	//  06  RC6
	NOT_ANALOG_PIN,	//  07  RC7

	NOT_ANALOG_PIN,	//  08  RB7		BUT
	NOT_ANALOG_PIN,	//  09  RA10	LED2
	NOT_ANALOG_PIN,	//  10  RB5		SD02
	NOT_ANALOG_PIN,	//  11  RB13	SDI2
	NOT_ANALOG_PIN,	//  12  RB15	SCK2/LED1

	// 8 special purpose digital ports
	NOT_ANALOG_PIN,	//  13 RA7	SS	(UEXT SPI)
	NOT_ANALOG_PIN,	//  14 RA9	SDO1(UEXT SPI)
	NOT_ANALOG_PIN,	//  15 RA8	SDI1(UEXT SPI)
	NOT_ANALOG_PIN,	//  16 RB14 SCK1(UEXT SPI)
	NOT_ANALOG_PIN,	//  17 RB8  SCL1(UEXT I2C)
	NOT_ANALOG_PIN,	//  18 RB9  SDA1(UEXT I2C)
	NOT_ANALOG_PIN,	//  19 RA4  U1RX
	NOT_ANALOG_PIN,	//  20 RB4  U1TX
	// 6 analog ports
    _BOARD_AN2,	//  21 RB0  A0  AN2
	_BOARD_AN3,	//  22 RB1  A1  AN3
	_BOARD_AN4,	//  23 RB2  A2  AN4
	_BOARD_AN5,	//  24 RB3  A3  AN5
	_BOARD_AN11,	//  25 RB13  A4  AN/(SDA2)
	_BOARD_AN6,	//  26 RC0  A5  AN6/(SCL2)
	_BOARD_AN0,	//  27 RA0  A6  AN4/(SDA2)
	_BOARD_AN1,	//  28 RA1  A7  AN5/(SCL2)

};
//#endif

/* ------------------------------------------------------------ */
/* This table is used to map from the analog pin number to the
** actual A/D converter channel used for that pin.
** In the default case, where there is a one-to-one mapping, this
** table isn't needed as the analogInPinToChannel() macro is defined
** to provide the mapping.
*/
//#if defined(_NOT_USED_)
const uint8_t analog_pin_to_channel_PGM[] = {
			//*	Arduino Pin		PIC32 Analog channel
	0,		//*	A0				1 to 1 mapping
	1,		//*	A1
	2,		//*	A2
	3,		//*	A3
	4,		//*	A4
	5,		//*	A5
	6,		//*	A6
	7,		//*	A7
	8,		//*	A8
	9,		//*	A9
	10,		//*	A10
	11,		//*	A11
	12,		//*	A12
	13,		//*	A13
	14,		//*	A14
	15,		//*	A15
};
//#endif

/* ------------------------------------------------------------ */
/* This table maps from an output compare number as stored in the
** digital_pin_to_timer_PGM table to the digital pin number of the
** pin that OC is connected to. This table is only required for
** devices that support peripheral pin select (PPS), i.e. PIC32MX1xx/2xx
** devices.
*/

const uint8_t output_compare_to_digital_pin_PGM[] = {
	NOT_PPS_PIN,				// There is no OC0, so this one needs to be blank
	/*
	PIN_OC1,					// A0, B3, B4, B15, B7  ; B15   RPB15R  = 5
	PIN_OC2,					// A1, B5, B1, B11, B8  ; B1    RPB1R   = 5
	PIN_OC3,					// A3, B14, B0, B10, B9 ; B0    RPB0R   = 5
	PIN_OC4,					// A2, B6, A4, B13, B2  ; B2    RPB2R   = 5
	PIN_OC5						// A2, B6, A4, B13, B2	; B13   RPB13R  = 6
	*/
};

/* ------------------------------------------------------------ */
/* This table maps from an external interrupt number to the digital
** pin for that interrupt.
*/

const uint8_t external_int_to_digital_pin_PGM[] = {
	NOT_PPS_PIN,			// INT0 is not mappable
	/*
	PIN_INT1,				// INT1
	PIN_INT2,				// INT2
	PIN_INT3,				// INT3
	PIN_INT4				// INT4
	*/
};

/* ------------------------------------------------------------ */
/*		Include Files for Board Customization Functions			*/
/* ------------------------------------------------------------ */


/* ------------------------------------------------------------ */
/*				Board Customization Functions					*/
/* ------------------------------------------------------------ */
/*																*/
/* The following can be used to customize the behavior of some	*/
/* of the core API functions. These provide hooks that can be	*/
/* used to extend or replace the default behavior of the core	*/
/* functions. To use one of these functions, add the desired	*/
/* code to the function skeleton below and then set the value	*/
/* of the appropriate compile switch above to 1. This will		*/
/* cause the hook function to be compiled into the build and	*/
/* to cause the code to call the hook function to be compiled	*/
/* into the appropriate core function.							*/
/*																*/
/* ------------------------------------------------------------ */
/***	_board_init
**
**	Parameters:
**		none
**
**	Return Value:
**		none
**
**	Errors:
**		none
**
**	Description:
**		This function is called from the core init() function.
**		This can be used to perform any board specific init
**		that needs to be done when the processor comes out of
**		reset and before the user sketch is run.
*/
#if	(OPT_BOARD_INIT != 0)

void _board_init(void) {

	/*	Turn off Secondary oscillator so pins can be used as GPIO
	*/
	OSCCONCLR	=	_OSCCON_SOSCEN_MASK;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_pinMode
**
**	Parameters:
**		pin		- digital pin number to configure
**		mode	- mode to which the pin should be configured
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the pinMode
**		function. It can perform any special processing needed
**		when setting the pin mode. If this function returns zero,
**		control will pass through the normal pinMode code. If
**		it returns a non-zero value the normal pinMode code isn't
**		executed.
*/
#if	(OPT_BOARD_DIGITAL_IO != 0)

int	_board_pinMode(uint8_t pin, uint8_t mode) {
	
	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_getPinMode
**
**	Parameters:
**		pin		- digital pin number
**		mode	- pointer to variable to receive mode value
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the getPinMode
**		function. It can perform any special processing needed
**		when getting the pin mode. If this function returns zero,
**		control will pass through the normal getPinMode code. If
**		it returns a non-zero value the normal getPinMode code isn't
**		executed.
*/
#if	(OPT_BOARD_DIGITAL_IO != 0)

int	_board_getPinMode(uint8_t pin, uint8_t * mode) {
	
	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_digitalWrite
**
**	Parameters:
**		pin		- digital pin number
**		val		- value to write to the pin
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the digitalWrite
**		function. It can perform any special processing needed
**		in writing to the pin. If this function returns zero,
**		control will pass through the normal digitalWrite code. If
**		it returns a non-zero value the normal digitalWrite code isn't
**		executed.
*/
#if	(OPT_BOARD_DIGITAL_IO != 0)

int	_board_digitalWrite(uint8_t pin, uint8_t val) {
	
	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_digitalRead
**
**	Parameters:
**		pin		- digital pin number
**		val		- pointer to variable to receive pin value
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the digitalRead
**		function. It can perform any special processing needed
**		in reading from the pin. If this function returns zero,
**		control will pass through the normal digitalRead code. If
**		it returns a non-zero value the normal digitalRead code isn't
**		executed.
*/
#if	(OPT_BOARD_DIGITAL_IO != 0)

int	_board_digitalRead(uint8_t pin, uint8_t * val) {
	
	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_analogRead
**
**	Parameters:
**		pin		- analog channel number
**		val		- pointer to variable to receive analog value
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the analogRead
**		function. It can perform any special processing needed
**		in reading from the pin. If this function returns zero,
**		control will pass through the normal analogRead code. If
**		it returns a non-zero value the normal analogRead code isn't
**		executed.
*/
#if (OPT_BOARD_ANALOG_READ != 0)

int	_board_analogRead(uint8_t pin, int * val) {

	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_analogReference
**
**	Parameters:
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the analogReference
**		function. It can perform any special processing needed
**		to set the reference voltage. If this function returns zero,
**		control will pass through the normal analogReference code. If
**		it returns a non-zero value the normal analogReference code isn't
**		executed.
*/
#if (OPT_BOARD_ANALOG_READ != 0)

int	_board_analogReference(uint8_t mode) {

	return 0;

}

#endif

/* ------------------------------------------------------------ */
/***	_board_analogWrite
**
**	Parameters:
**		pin		- pin number
**		val		- analog value to write
**
**	Return Value:
**		Returns 0 if not handled, !0 if handled.
**
**	Errors:
**		none
**
**	Description:
**		This function is called at the beginning of the analogWrite
**		function. It can perform any special processing needed
**		in writing to the pin. If this function returns zero,
**		control will pass through the normal analogWrite code. If
**		it returns a non-zero value the normal analogWrite code isn't
**		executed.
*/
#if (OPT_BOARD_ANALOG_WRITE != 0)

int	_board_analogWrite(uint8_t pin, int val) {

	return 0;

}

#endif

#endif // OPT_BOARD_DATA

/* ------------------------------------------------------------ */

#endif	// BOARD_DATA_C

/************************************************************************/
