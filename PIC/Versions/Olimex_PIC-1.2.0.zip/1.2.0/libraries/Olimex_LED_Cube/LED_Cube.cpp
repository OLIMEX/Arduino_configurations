#include "LED_Cube.h"
#include <SPI.h>
#include "font.h"

#define	ASCENDING(A,B) if (A>B) {A=A^B;B=A^B;A=A^B;}
#define	DESCENDING(A,B) if (A<B) {A=A^B;B=A^B;A=A^B;}

const long int Palette[48] = {0xFF0000, 0xFF2000, 0xFF4000, 0xFF6000, 0xFF8000, 0xFFA000, 0xFFC000, 0xFFE000, 0xFFFF00, 0xE0FF00, 0xC0FF00, 0xA0FF00, 0x80FF00, 0x60FF00, 0x40FF00, 0x20FF00, 0x00FF00, 0x00FF20, 0x00FF40, 0x00FF60, 0x00FF80, 0x00FFA0, 0x00FFC0, 0x00FFE0, 0x00FFFF, 0x00E0FF, 0x00C0FF, 0x00A0FF, 0x0080FF, 0x0060FF, 0x0040FF, 0x0020FF, 0x0000FF, 0x2000FF, 0x4000FF, 0x6000FF, 0x8000FF, 0xA000FF, 0xC000FF, 0xE000FF, 0xFF00FF, 0xFF00E0, 0xFF00C0, 0xFF00A0, 0xFF0080, 0xFF0060, 0xFF0040, 0xFF0020};

LED_Cube::LED_Cube ()
{
	SPI.begin();
	SPI2BRG = SPI_CLOCK_DIV2;
	Brightness = 100;
}

LED_Cube::LED_Cube (uint8_t Divider)
{
	SPI.begin();
	SPI2BRG = Divider;
	Brightness = 100;
}

void LED_Cube::Set_Brightness (int New_Brightness)
{
	int i;
	if (New_Brightness > 100)
		New_Brightness = 100;
	if (New_Brightness < 1)
		New_Brightness = 1;

	for (i=0; i<LED_COUNT; i++)
	{
		LED_Frame[i].GRB.G = (double) LED_Frame[i].GRB.G * New_Brightness / Brightness;
		LED_Frame[i].GRB.R = (double) LED_Frame[i].GRB.R * New_Brightness / Brightness;
		LED_Frame[i].GRB.B = (double) LED_Frame[i].GRB.B * New_Brightness / Brightness;
	}
	Brightness = New_Brightness;
	Update ();
}

void LED_Cube::Change_Brightness (int Percentage)
{
	Set_Brightness (Brightness + Percentage);
}

void LED_Cube::Update ()
{
	int i; 
	for (i=0; i<LED_COUNT; i++)
	{
		// since timing is very critical - the following code is written
		// that way instead of using a 'for' cycle, because too much time
		// is wasted with increment, condition and calculating the mask
		// GREEN
		if (LED_Frame[i].GRB.G & 0x80) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x40) SPI.transfer (ONE); else	SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x20) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x10) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x08) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x04) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x02) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.G & 0x01) SPI.transfer (ONE); else SPI.transfer (ZERO);

		// RED
		if (LED_Frame[i].GRB.R & 0x80) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x40) SPI.transfer (ONE); else	SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x20) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x10) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x08) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x04) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x02) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.R & 0x01) SPI.transfer (ONE); else SPI.transfer (ZERO);

		// BLUE
		if (LED_Frame[i].GRB.B & 0x80) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x40) SPI.transfer (ONE); else	SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x20) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x10) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x08) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x04) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x02) SPI.transfer (ONE); else SPI.transfer (ZERO);
		if (LED_Frame[i].GRB.B & 0x01) SPI.transfer (ONE); else SPI.transfer (ZERO);
	}
	delayMicroseconds (100);	// more than 50 us
}

void LED_Cube::Clear_Cube (bool Refresh)
{
	memset ((void*)LED_Frame, 0, LED_COUNT*sizeof(LED_Color));
	if (Refresh)
		Update ();
}

long int LED_Cube::Get_LED (uint8_t X, uint8_t Y, uint8_t Z)
{
	LED_Color Temp;
	Temp.Color = LED_Frame[X*8 + Y + (7-Z)*64].Color;
	Temp.GRB.G = (double) Temp.GRB.G * 100 / Brightness;
	Temp.GRB.R = (double) Temp.GRB.R * 100 / Brightness;
	Temp.GRB.B = (double) Temp.GRB.B * 100 / Brightness;
	return Temp.Color;
}

void LED_Cube::Set_LED (uint8_t X, uint8_t Y, uint8_t Z, long int Color)
{
	Set_LED (X, Y, Z, Color, false);
}

void LED_Cube::Set_LED (uint8_t X, uint8_t Y, uint8_t Z, Gradient Color)
{
	Set_LED (X, Y, Z, *(long int*) &Color, false);
}

void LED_Cube::Set_LED (uint8_t X, uint8_t Y, uint8_t Z, long int Color, bool Overlap)
{
	LED_Color Temp;
	if (Overlap)
	{
		long int Current_Color;
		Current_Color = Get_LED (X, Y, Z);
		Color = Current_Color | Color;
	}
	Temp.Color = Color;
	Temp.GRB.G = (double) Temp.GRB.G * Brightness / 100;
	Temp.GRB.R = (double) Temp.GRB.R * Brightness / 100;
	Temp.GRB.B = (double) Temp.GRB.B * Brightness / 100;
	LED_Frame[X*8 + Y + (7-Z)*64].Color = Temp.Color;
}

// draw an orthogonal line (parallel to two of the axes)
void LED_Cube::Draw_Orthogonal_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color)
{
	Draw_Orthogonal_Line (X1, Y1, Z1, X2, Y2, Z2, Color, false);
}

void LED_Cube::Draw_Orthogonal_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color, bool Overlap)
{
	uint8_t i;

	if ((X1==X2) && (Y1==Y2))
	{
		ASCENDING(Z1, Z2);
		for (i=Z1; i<=Z2; i++)
			Set_LED (X1, Y1, i, Color, Overlap);
		return;
	}

	if ((Y1==Y2) && (Z1==Z2))
	{
		ASCENDING(X1, X2);
		for (i=X1; i<=X2; i++)
			Set_LED (i, Y1, Z1, Color, Overlap);
		return;
	}

	if ((Z1==Z2) && (X1==X2))
	{
		ASCENDING(Y1, Y2);
		for (i=Y1; i<=Y2; i++)
			Set_LED (X1, i, Z1, Color, Overlap);
		return;
	}
}

// draw parallelepiped using coordinates of two opposite edges (diagonal)
void LED_Cube::Draw_Parallelepiped (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, unsigned long Color, uint8_t Filled)
{
	Draw_Parallelepiped (X1, Y1, Z1, X2, Y2, Z2, Color, Filled, false);
}

void LED_Cube::Draw_Parallelepiped (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, unsigned long Color, uint8_t Filled, bool Overlap)
{
	uint8_t i, j, k;

	ASCENDING(X1, X2);
	ASCENDING(Y1, Y2);
	ASCENDING(Z1, Z2);

	// borders only (NO_FILL)
	Draw_Orthogonal_Line (X1, Y1, Z1, X2, Y1, Z1, Color, Overlap);
	Draw_Orthogonal_Line (X2, Y1, Z1, X2, Y2, Z1, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y2, Z1, X2, Y2, Z1, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y1, Z1, X1, Y2, Z1, Color, Overlap);
	Draw_Orthogonal_Line (X2, Y1, Z1, X2, Y1, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X2, Y2, Z1, X2, Y2, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X2, Y1, Z2, X2, Y2, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y1, Z1, X1, Y1, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y2, Z1, X1, Y2, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y1, Z2, X1, Y2, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y1, Z2, X2, Y1, Z2, Color, Overlap);
	Draw_Orthogonal_Line (X1, Y2, Z2, X2, Y2, Z2, Color, Overlap);

	// inside only (FILL_INSIDE)
	if (Filled & FILL_INSIDE)
	{
		for (i=X1+1; i<X2; i++)
			for (j=Y1+1; j<Y2; j++)
				for (k=Z1+1; k<Z2; k++)
					Set_LED (i, j, k, Color, Overlap);
	}

	// walls only (FILL_WALLS)
	if (Filled & FILL_WALLS)
	{
		for (i=X1; i<=X2; i++)
			for (j=Y1; j<=Y2; j++)
			{
				Set_LED (i, j, Z1, Color, Overlap);
				Set_LED (i, j, Z2, Color, Overlap);
			}

		for (i=Y1; i<=Y2; i++)
			for (j=Z1; j<=Z2; j++)
			{
				Set_LED (X1, i, j, Color, Overlap);
				Set_LED (X2, i, j, Color, Overlap);
			}

		for (i=Z1; i<=Z2; i++)
			for (j=X1; j<=X2; j++)
			{
				Set_LED (j, Y1, i, Color, Overlap);
				Set_LED (j, Y2, i, Color, Overlap);
			}
	}
	delay (1);
}

// Bresenham 3d Line Drawing Algorithm - https://gist.github.com/yamamushi/5823518
void LED_Cube::Draw_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color)
{
	int i, dx, dy, dz, l, m, n, x_inc, y_inc, z_inc, err_1, err_2, dx2, dy2, dz2;
	int point[3];

	point[0] = X1;
	point[1] = Y1;
	point[2] = Z1;
	dx = X2 - X1;
	dy = Y2 - Y1;
	dz = Z2 - Z1;
	x_inc = (dx < 0) ? -1 : 1;
	l = abs(dx);
	y_inc = (dy < 0) ? -1 : 1;
	m = abs(dy);
	z_inc = (dz < 0) ? -1 : 1;
	n = abs(dz);
	dx2 = l << 1;
	dy2 = m << 1;
	dz2 = n << 1;

	if ((l >= m) && (l >= n))
	{
		err_1 = dy2 - l;
		err_2 = dz2 - l;
		for (i = 0; i < l; i++)
		{
			Set_LED (point[0], point[1], point[2], Color);
			if (err_1 > 0)
			{
				point[1] += y_inc;
				err_1 -= dx2;
			}
			if (err_2 > 0)
			{
				point[2] += z_inc;
				err_2 -= dx2;
			}
			err_1 += dy2;
			err_2 += dz2;
			point[0] += x_inc;
		}
	}
	else
	if ((m >= l) && (m >= n))
	{
		err_1 = dx2 - m;
		err_2 = dz2 - m;
		for (i = 0; i < m; i++)
		{
			Set_LED (point[0], point[1], point[2], Color);
			if (err_1 > 0)
			{
				point[0] += x_inc;
				err_1 -= dy2;
			}
			if (err_2 > 0)
			{
				point[2] += z_inc;
				err_2 -= dy2;
			}
			err_1 += dx2;
			err_2 += dz2;
			point[1] += y_inc;
		}
	}
	else
	{
		err_1 = dy2 - n;
		err_2 = dx2 - n;
		for (i = 0; i < n; i++)
		{
			Set_LED (point[0], point[1], point[2], Color);
			if (err_1 > 0)
			{
				point[1] += y_inc;
				err_1 -= dz2;
			}
			if (err_2 > 0)
			{
				point[0] += x_inc;
				err_2 -= dz2;
			}
			err_1 += dy2;
			err_2 += dx2;
			point[2] += z_inc;
		}
	}
	Set_LED (point[0], point[1], point[2], Color);
}

// http://stackoverflow.com/questions/24959928/3d-fireworks-effect-in-c-c-using-sine-or-cosine-function/24960217
void LED_Cube::Draw_Sphere(uint8_t x0, uint8_t y0, uint8_t z0, uint8_t r, long int Color)
{
	const char n=8;
	int x, y, z, xa, ya, za, xb, yb, zb, xr, yr, zr, xx, yy, zz, rr=r*r;
	// bounding box
	xa=x0-r; if (xa<0) xa=0; xb=x0+r; if (xb>n) xb=n;
	ya=y0-r; if (ya<0) ya=0; yb=y0+r; if (yb>n) yb=n;
	za=z0-r; if (za<0) za=0; zb=z0+r; if (zb>n) zb=n;
	// project xy plane
	for (x=xa,xr=x-x0,xx=xr*xr;x<xb;x++,xr++,xx=xr*xr)
		for (y=ya,yr=y-y0,yy=yr*yr;y<yb;y++,yr++,yy=yr*yr)
		{
			zz=rr-xx-yy; if (zz<0) continue; zr=sqrt(zz);
			z=z0-zr; if ((z>0)&&(z<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
			z=z0+zr; if ((z>0)&&(z<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
		}
	// project xz plane
	for (x=xa,xr=x-x0,xx=xr*xr;x<xb;x++,xr++,xx=xr*xr)
		for (z=za,zr=z-z0,zz=zr*zr;z<zb;z++,zr++,zz=zr*zr)
		{
			yy=rr-xx-zz; if (yy<0) continue; yr=sqrt(yy);
			y=y0-yr; if ((y>0)&&(y<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
			y=y0+yr; if ((y>0)&&(y<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
		}
	// project yz plane
	for (y=ya,yr=y-y0,yy=yr*yr;y<yb;y++,yr++,yy=yr*yr)
		for (z=za,zr=z-z0,zz=zr*zr;z<zb;z++,zr++,zz=zr*zr)
		{
			xx=rr-zz-yy; if (xx<0) continue; xr=sqrt(xx);
			x=x0-xr; if ((x>0)&&(x<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
			x=x0+xr; if ((x>0)&&(x<n)) Set_LED(x, y, z, Color); // map[x][y][z]=col;
		}
}

/*
Text_Buffer
  7	00 27 26 25 24 23 22 21
  6	01                   20
  5	02                   19
  4	03                   18
  3	04                   17
  2	05                   16
  1	06                   15
Z^0	07 08 09 10 11 12 13 14
 X>  0  1  2  3  4  5  6  7
*/
void LED_Cube::Set_Text (uint8_t Input[])
{
	Set_Text (Input, false);
}

void LED_Cube::Set_Text (uint8_t Input[], bool Reset)
{
	uint8_t C;
	int i, PicColumn, CharIndex, CharColumn;
	for (Length=0; Input[Length]; Length++)
		Text[Length] = Input[Length];
	if (Length == 0)
		return;
	if (Reset)
		Offset = 0;

	for (i=0; i<28; i++)
	{
		PicColumn = (Offset+i) % (Length*CHAR_WIDTH);	// if the new column is outside of the text start over from beginning
		CharIndex = PicColumn / CHAR_WIDTH;				// calculate which character
		CharColumn =  PicColumn % CHAR_WIDTH;			// calculate which column of the character
		if (CharIndex >= Length)
			C = 0;
		else
			C = Text[CharIndex]-32;
		#if defined	_8X5
		if (CharColumn%CHAR_WIDTH==5)
			Text_Buffer[i].Data = 0;
		else
		#endif
			Text_Buffer[i].Data = FontLookup[C][CharColumn];

		Text_Buffer[i].Color = Palette [(CharIndex*8) % 48];
	}
}

void LED_Cube::Show_Text ()
{
	uint8_t i, j, Mask;
	long int Color;

	for (i=0; i<7; i++)
	{
		Mask = 0x80;
		for (j=0; j<8; j++)
		{
			if (Text_Buffer[i].Data & Mask) Color = Text_Buffer[i].Color; else Color = 0;
			Set_LED (0, j, 7-i, Color);

			if (Text_Buffer[i+7].Data & Mask) Color = Text_Buffer[i+7].Color; else Color = 0;
			Set_LED (i, j, 0, Color);

			if (Text_Buffer[i+14].Data & Mask) Color = Text_Buffer[i+14].Color; else Color = 0;
			Set_LED (7, j, i, Color);

			if (Text_Buffer[i+21].Data & Mask) Color = Text_Buffer[i+21].Color; else Color = 0;
			Set_LED (7-i, j, 7, Color);

			Mask = Mask >> 1;
		}
	}
	Update ();
}

void LED_Cube::Slide_Text (char Direction)
{
	Slide_Text (Direction, true);
}

void LED_Cube::Slide_Text (char Direction, bool Refresh)
{
	int i, PicColumn, CharIndex, CharColumn;

	Offset = Offset + Direction;
	if (Offset < 0)
		Offset = Length*CHAR_WIDTH-1;

	if (Offset >= Length*CHAR_WIDTH)
		Offset = 0;

	if (Direction == LEFT)
		for (i=0; i<27; i++)
			Text_Buffer[i] = Text_Buffer[i+1];

	if (Direction == RIGHT)
		for (i=27; i>0; i--)
			Text_Buffer[i] = Text_Buffer[i-1];

	PicColumn = (Offset+i) % (Length*CHAR_WIDTH);	// if the new column is outside of the text start over from beginning
	CharIndex = PicColumn / CHAR_WIDTH;				// calculate which character
	CharColumn =  PicColumn % CHAR_WIDTH;			// calculate which column of the character

	#if defined	_8X5
	if (CharColumn == 5)
		Text_Buffer[i].Data = 0;
	else
	#endif
		Text_Buffer[i].Data = FontLookup[Text[CharIndex]-32][CharColumn];

	Text_Buffer[i].Color = Palette [(CharIndex*8) % 48];

	if (Refresh)
		Show_Text ();
}

void LED_Cube::Flow (int Mode)
{
	unsigned char i, j, k;
	static char Flow_Offset = 0, FlowColor=0;
	switch (Mode)
	{
		case 0:	// diagonal
			Clear_Cube (false);
			for (i=0; i<8; i++)
				for (j=0; j<8; j++)
					for (k=0; k<8; k++)
						Set_LED (i, j, k, Palette[(i+j+k+Flow_Offset)%48]);
			Flow_Offset = (Flow_Offset + 1) % 48;
		break;
		case 1:	// middle to outside
			Clear_Cube (false);
			for (i=0; i<4; i++)
				Draw_Parallelepiped (0+i, 0+i, 0+i, 7-i, 7-i, 7-i, Palette[(FlowColor+i*4)%48], FILL_WALLS);
			FlowColor = (FlowColor+1)%48;
		break;
		case 2:	// outside to middle
			Clear_Cube (false);
			for (i=0; i<4; i++)
				Draw_Parallelepiped (4+i, 4+i, 4+i, 3-i, 3-i, 3-i, Palette[(FlowColor+i*4)%48], FILL_WALLS);
			FlowColor = (FlowColor+1)%48;
		break;
	}
	Update ();
}

void LED_Cube::Random ()
{
	int i;
	for (i=0; i<LED_COUNT; i++)
	{
		if (!random(4))
		{
			LED_Frame[i].GRB.G = (long int) random (256) * Brightness / 100;
			LED_Frame[i].GRB.R = (long int) random (256) * Brightness / 100;
			LED_Frame[i].GRB.B = (long int) random (256) * Brightness / 100;
		}
		else
		{
			LED_Frame[i].Color = 0;
		}
	}
	Update ();
}

void LED_Cube::Random2 ()
{
	int i;
	for (i=0; i<LED_COUNT; i++)
	{
		if (!random(4))
		{
			LED_Frame[i].Color = Palette[random (48)];
			LED_Frame[i].GRB.G = (long int) LED_Frame[i].GRB.G * Brightness / 100;
			LED_Frame[i].GRB.R = (long int) LED_Frame[i].GRB.R * Brightness / 100;
			LED_Frame[i].GRB.B = (long int) LED_Frame[i].GRB.B * Brightness / 100;
		}
		else
		{
			LED_Frame[i].Color = 0;
		}
	}
	Update ();
}
