#ifndef	_LED_CUBE
#define	_LED_CUBE

#include <stdint.h>

#define	LED_COUNT	512

#define	ZERO	0xE0	// 0b11100000 -> H ~400 ns; L ~700 ns
#define	ONE		0xF8	// 0b11111000 -> H ~700 ns; L ~400 ns

// macros for Draw_Parallelepiped method
#define	NO_FILL		0
#define	FILL_WALLS	1
#define	FILL_INSIDE	2
#define	FILL_ALL	3

// Text macros
#define	TEXT_SIZE	100
#define	LEFT	1
#define	RIGHT	-1

extern const long int Palette[48];

struct Gradient
{
	uint8_t B, R, G;	// order is reversed because of the little endian
};
	
union LED_Color
{
	Gradient GRB;
	long int Color;
};

struct Text_Column
{
	uint8_t Data;
	long int Color;
};

class LED_Cube
{
	LED_Color LED_Frame[LED_COUNT];
	Text_Column Text_Buffer[28];
	uint8_t Text[TEXT_SIZE], Length;	// Text variables
	int Brightness, Offset;
public:
	LED_Cube ();
	LED_Cube (uint8_t SPI_Divider);
	void Set_Brightness (int New_Brightness);
	void Change_Brightness (int Percentage);
	void Update ();
	void Clear_Cube (bool Refresh);
	long int Get_LED (uint8_t X, uint8_t Y, uint8_t Z);
	void Set_LED (uint8_t X, uint8_t Y, uint8_t Z, long int Color);
	void Set_LED (uint8_t X, uint8_t Y, uint8_t Z, Gradient Color);
	void Set_LED (uint8_t X, uint8_t Y, uint8_t Z, long int Color, bool Overlap);
	
	void Draw_Orthogonal_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color);
	void Draw_Orthogonal_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color, bool Overlap);
	void Draw_Parallelepiped (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, unsigned long Color, uint8_t Filled);
	void Draw_Parallelepiped (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, unsigned long Color, uint8_t Filled, bool Overlap);
	
	void Draw_Line (uint8_t X1, uint8_t Y1, uint8_t Z1, uint8_t X2, uint8_t Y2, uint8_t Z2, long int Color);
	void Draw_Sphere (uint8_t x0, uint8_t y0, uint8_t z0, uint8_t r, long int Color);

	void Set_Text (uint8_t Input[]);
	void Set_Text (uint8_t Input[], bool Reset);
	void Show_Text ();
	void Slide_Text (char Direction);
	void Slide_Text (char Direction, bool Refresh);

	void Flow (int Mode);
	void Random ();
	void Random2 ();
};

#endif
