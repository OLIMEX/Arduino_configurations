#include <stdio.h>
#include <stdlib.h>

int main ()
{
	char InputFileName[20], OutputFileName[20];
	FILE *Input, *Output;
	int i, j;
	int In[5], Out[5], Mask;
	char CurrentSymbol = ' ';
	
	printf ("Input file: ");
	scanf ("%s", InputFileName);
	
	printf ("Output file: ");
	scanf ("%s", OutputFileName);
	
	Input = fopen (InputFileName, "r");
	Output = fopen (OutputFileName, "w");

	while (!feof(Input))
	{
		for (i=0; i<5; i++)
			fscanf (Input, "%x", &In[i]);
		
		Mask = 0x80;
		for (i=0; i<5; i++)
		{
			int Temp = 0;
			for (j=0; j<5; j++)
			{
				if (In[j] & Mask)
					Temp = Temp | (1<<j);
			}
			Out[i] = Temp;
			Mask = Mask >> 1;
		}
		
		fprintf (Output, "\t{0x%X,\t0x%X,\t0x%X,\t0x%X,\t0x%X},\t// %c\n", Out[0], Out[1], Out[2], Out[3], Out[4], CurrentSymbol);
		CurrentSymbol++;
	}
	
	fclose (Input);
	fclose (Output);
	return 0;
}
